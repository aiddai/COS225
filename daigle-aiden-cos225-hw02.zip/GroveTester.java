public class GroveTester {
    public static void main(String[] args) {
        Grove grove1 = new Grove("Grove 1");
        System.out.println(grove1);

        for(int i = 0; i < 6; i++){
            Tree spruceTree = new Tree(i,37,"Spruce");
            grove1.plantTree(spruceTree);
        }

        System.out.println(grove1);

        grove1.rmTree(3);
        grove1.rmTree(5);

        System.out.println(grove1);
        Tree mapleTree = new Tree(7, 13, "Maple");
        grove1.plantTree(mapleTree);

        System.out.println(grove1);
    }
}
