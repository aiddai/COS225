public class Tree {
    private int id; 
    private int age;
    private String species;

    public Tree(int id,int age, String species){
        this.id = id;
        this.age = age;
        this.species = species;
    }
    public static void main(String[] args){

    }
}
