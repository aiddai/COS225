import java.util.ArrayList;
public class Grove {
    private String name;
    private ArrayList<Tree> treeArray = new ArrayList<>();

    public Grove(String name){
        this.name = name;
        for(int i =0; i < 15;i++){
            treeArray.add(null); // initialize both arrayLists with null-- 
                                        // null indicates no tree at the given index
        }
    }

    int plantTree(Tree treeObj){
        int freeSpace = treeArray.indexOf(null);
        if(freeSpace != -1){
            treeArray.set(freeSpace, treeObj);  // plantTree: adds a treeobj to the first occurance of null
            return freeSpace;
        }
        return -1;
    }  

    Tree rmTree(int index){
        Tree treeIndex = treeArray.get(index); // remove tree: sets specified index to null
        treeArray.set(index, null);
        return treeIndex;
    }
    @Override
    public String toString(){
        int count = 0;
        for(int i = 0; i < 15; i++){
            if(treeArray.get(i) != null){
                count++;
            }
    
        }
        return String.valueOf(count);
    }

    public static void main(String[] args){
    }

}


